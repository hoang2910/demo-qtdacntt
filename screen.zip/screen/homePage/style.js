import { StyleSheet } from 'react-native';

import color from '../../basecss/color'

const styles = StyleSheet.create({
    container: {
        flex: 1,
        position: 'relative',
        backgroundColor: color.whiteColor,
    },
    header: {
        flex: 1,
        borderBottomLeftRadius: 50,
        borderBottomRightRadius: 50,
    },
    titlle: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20,
        flexDirection: 'row',
        display: 'flex',
    },
    imageStyle: {
        width: 50,
        height: 50,
        marginTop: 15,
    },
    headingHome: {
        fontWeight: 'bold',
        fontSize: 20,
        marginTop: 28,
        paddingLeft: 5,
    },
    formGroup: {
        flex: 5,
        backgroundColor: '#f1f1f1',
    },
    formGroupNavbar: {
        flex: 1,
        backgroundColor: color.whiteColor,
    },
    formGroupHeader: {
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 20,
        backgroundColor: color.whiteColor,
        borderRadius: 15,
        paddingVertical: 16,
        marginTop: -33,
        paddingHorizontal: 20,
        marginHorizontal: 12,
        flexDirection: 'row',
        shadowColor: 'black',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
    },
    houseRent: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    color: {
        color: '#ff6e46',
    },
    iconHouseRent: {
        padding: 16,
        marginBottom: 8,
    },
    houseRentText: {
        fontSize: 15,
    },
    formGroupManage: {
        marginTop: 20,
        backgroundColor: color.whiteColor,
        borderRadius: 15,
        paddingVertical: 16,
        paddingHorizontal: 20,
        marginHorizontal: 12,
        flexDirection: 'row',
        shadowColor: 'black',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
        width: '94%',
        flexWrap: 'wrap',
        backgroundColor: '#f1f1f1',
    },
    groupManageText: {
        width: '100%',
        fontSize:20,
        fontWeight: 'bold',
        color: '#000',
    },
    manageBill: {
        width: '25%',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginVertical: 15,
    },
    backgroundmanage: {
        borderRadius: 500,
        backgroundColor : color.whiteColor,
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
    },
    manageIcon: {
        padding: 12,
        margin:20,
        alignItems: 'center',
        backgroundColor: color.whiteColor,
        borderRadius: 500,
    },
    manageText:{
        fontSize: 15,
        color: color.blackColor,
    },
    separateWidth: {
        borderBottomWidth: 1,
        borderBottomColor: '#999',
        height: 0,
        width: '98%',
        marginVertical:20,
    },
    formGroupNavbar:{
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 20,
        marginBottom: 8,
        backgroundColor: color.whiteColor,
        paddingHorizontal:12,
        flexDirection: 'row',
    },
    iconStatic:{
        color:'#fff',
        alignItems: 'center',
        backgroundColor: '#ff6e46',
        borderRadius: 500,
        padding: 12,
    },
    navBarStatisticText:{
        marginTop: 20,
    },
    navBarcolorStatis:{
        position: 'absolute',
        alignItems: 'center',
        justifyContent  : 'center',
        top: -48,
        padding:35,
        borderRadius:500,
        backgroundColor: '#fff',
        shadowColor: 'black',
    },
    navBarStatic:{
        padding: 10,
        backgroundColor: '#ff6e46',
        position: 'absolute',
        borderRadius:200,
    },
    iconNavbar:{
        padding: 14,
        alignItems: 'center',
        justifyContent: 'center',
        color: '#333',
    },
    navBar:{
        alignItems: 'center',
        justifyContent: 'center',
    }

});

export default styles;