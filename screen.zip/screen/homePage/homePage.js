import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ImageBackground, ScrollView, Image } from 'react-native';

import styles from './style';
import { LinearGradient } from 'expo-linear-gradient'

import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { faHouse } from '@fortawesome/free-solid-svg-icons/faHouse'
import { faDoorOpen } from '@fortawesome/free-solid-svg-icons/faDoorOpen'
import { faBed } from '@fortawesome/free-solid-svg-icons/faBed'
import { faPersonBooth } from '@fortawesome/free-solid-svg-icons/faPersonBooth'
import { faFileContract } from '@fortawesome/free-solid-svg-icons/faFileContract'
import { faCoins } from '@fortawesome/free-solid-svg-icons/faCoins'
import { faKey } from '@fortawesome/free-solid-svg-icons/faKey'
import { faUserTie } from '@fortawesome/free-solid-svg-icons/faUserTie'
import { faLightbulb } from '@fortawesome/free-solid-svg-icons/faLightbulb'
import { faPeopleRoof } from '@fortawesome/free-solid-svg-icons/faPeopleRoof'
import { faMoneyBillTransfer } from '@fortawesome/free-solid-svg-icons/faMoneyBillTransfer'
import { faBell } from '@fortawesome/free-solid-svg-icons/faBell'
import { faCircleUser } from '@fortawesome/free-solid-svg-icons/faCircleUser'
import { faChartLine } from '@fortawesome/free-solid-svg-icons/faChartLine'


const HomePage = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <LinearGradient colors={['#f5b41a', '#ff6e46']} style={styles.header}>
                <View style={styles.titlle}>
                    <Image style={styles.imageStyle} resizeMode='contain' source={require('./../../assets/logoApp.png')}></Image>
                    <Text style={styles.headingHome}>IZZY LEASING</Text>
                </View>
            </LinearGradient>
            <View style={styles.formGroup}>
                <View style={styles.formGroupHeader}>
                    <TouchableOpacity style={styles.houseRent} onPress={() => { navigation.navigate('HouseManagement') }}>
                        <FontAwesomeIcon style={[styles.iconHouseRent]} icon={faHouse} />
                        <Text style={styles.houseRentText}>Thuê Nhà</Text>
                    </TouchableOpacity>
                    <View style={styles.houseRent}>
                        <FontAwesomeIcon style={styles.iconHouseRent} icon={faDoorOpen} />
                        <Text style={styles.houseRentText}>Thuê Phòng</Text>
                    </View>
                    <View style={styles.houseRent}>
                        <FontAwesomeIcon style={[styles.iconHouseRent]} icon={faBed} />
                        <Text style={styles.houseRentText}>Thuê Giường</Text>
                    </View>
                </View>
                <View style={styles.formGroupManage}>
                    <Text style={styles.groupManageText}>Quản lý</Text>
                    <View style={styles.separateWidth}></View>
                    <View style={styles.manageBill}>
                        <View style={styles.backgroundmanage}>
                            <FontAwesomeIcon style={[styles.manageIcon, styles.color]} icon={faPersonBooth} />
                        </View>
                        <Text style={styles.manageText}>Theo dõi</Text>
                    </View>
                    <View style={styles.manageBill}>
                        <View style={styles.backgroundmanage}>
                            <FontAwesomeIcon style={[styles.manageIcon, styles.color]} icon={faFileContract} />
                        </View>
                        <Text style={styles.manageText}>Hợp đồng</Text>
                    </View>
                    <View style={styles.manageBill}>
                        <View style={styles.backgroundmanage}>
                            <FontAwesomeIcon style={[styles.manageIcon, styles.color]} icon={faCoins} />
                        </View>
                        <Text style={styles.manageText}>Hóa đơn</Text>
                    </View>
                    <View style={styles.manageBill}>
                        <View style={styles.backgroundmanage}>
                            <FontAwesomeIcon style={[styles.manageIcon, styles.color]} icon={faKey} />
                        </View>
                        <Text style={styles.manageText}>Cọc giữ chỗ</Text>
                    </View>
                    <TouchableOpacity style={styles.formSubmit} onPress={() => { navigation.navigate('Dashboard') }}>

                    </TouchableOpacity>
                    <View style={styles.manageBill}>
                        <View style={styles.backgroundmanage}>
                            <TouchableOpacity style={styles.formSubmit} onPress={() => { navigation.navigate('Tenants') }}>
                                <FontAwesomeIcon style={[styles.manageIcon, styles.color]} icon={faUserTie} />
                            </TouchableOpacity>
                        </View>
                        <Text style={styles.manageText}>Khách thuê</Text>
                    </View>
                    <View style={styles.manageBill}>
                        <View style={styles.backgroundmanage}>
                            <FontAwesomeIcon style={[styles.manageIcon, styles.color]} icon={faLightbulb} />
                        </View>
                        <Text style={styles.manageText}>Dịch vụ</Text>
                    </View>
                </View>
            </View>
            <View style={styles.formGroupNavbar}>
                <View style={styles.navBar}>
                    <FontAwesomeIcon style={[styles.iconNavbar, styles.color]} icon={faPeopleRoof} />
                    <Text style={styles.navBarHomePageText}>Trang chủ</Text>
                </View>
                <View style={styles.navBar}>
                    <FontAwesomeIcon style={styles.iconNavbar} icon={faMoneyBillTransfer} />
                    <Text style={styles.navBarBillText}>Hợp đồng</Text>
                </View>
                <TouchableOpacity style={styles.formSubmit} onPress={() => { navigation.navigate('Dashboard') }}>
                    <View style={styles.navBar}>
                        <View style={styles.navBarcolorStatis}>
                            <View style={styles.navBarStatic}>
                                <FontAwesomeIcon style={[styles.iconStatic]} icon={faChartLine} />
                            </View>
                        </View>
                        <Text style={styles.navBarStatisticText}>Thống kê</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.navBar}>
                    <FontAwesomeIcon style={styles.iconNavbar} icon={faBell} />
                    <Text style={styles.navBarAlertText}>Thông Báo</Text>
                </View>
                <TouchableOpacity style={styles.formSubmit} onPress={() => { navigation.navigate('Account') }}>
                    <View style={styles.navBar}>
                        <FontAwesomeIcon style={styles.iconNavbar} icon={faCircleUser} />
                        <Text style={styles.navBarUserText}>Tài Khoản</Text>
                    </View>
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default HomePage;