import { StyleSheet } from 'react-native';

import color from '../../basecss/color'

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: color.whiteColor,
    },

    header: {
        flex: 1,
        borderBottomLeftRadius: 50,
        borderBottomRightRadius: 50,
    },
    titleHouse: {
        flexDirection: 'row',
        alignItems: 'center',
        top: 35,
        left: 12,
    },
    iconArrow: {
        padding:13,
        color : color.whiteColor
    },
    titleHeading:{
        color : color.whiteColor,
        marginLeft: 10,
        fontSize: 17,
        fontWeight: '400',
    },
    tabManagement:{
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '90%',
        alignItems: 'center',
        top: 60,
        left: 6,
    },
    active:{
        borderWidth: 1,
        borderRadius: 15,
        borderColor: '#f7c5b7',
        backgroundColor: '#fb954a',
    },
    management:{
        color : color.whiteColor,
        fontSize: 17,
        paddingHorizontal: 28,
        paddingVertical:6,
    },
    headerSearch:{
        width: 385,
        minHeight: 7,
        padding: 7,
        backgroundColor: '#fff',
        borderRadius: 13,
        marginTop: -30,
        marginLeft:14,
        shadowColor: 'black',
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
    },
    formGroup: {
        flex: 4,
        elevation: 2,
        backgroundColor: '#f1f1f1',
    },
    houseList:{
        width:'100%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
    },
    houseItem:{
        width:'43%',
        margin: 13,
        shadowColor: 'black',
        borderWidth: 1,
        borderRadius: 15,
        borderColor: '#f7c5b7',
        padding:2,
        paddingBottom:20,
        position: 'relative',
    },
    imageStyleHouse:{
        width: 171,
        height: 130,
        borderRadius:8,
        overflow: 'hidden',
    },
    imageIconHouse:{
        width: 38,
        height: 33,
        backgroundColor: 'rgba(51, 51, 51, 0.4)',
        borderRadius: 6,
        margin: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    IconHouse:{
        padding:10,
        color:color.whiteColor,
    },
    textHouse:{
        width: 38,
        height: 22,
        backgroundColor: 'rgba(13, 102, 13, 0.7)',
        borderRadius: 6,
        margin: 8,
        marginTop: 12,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top: 0,
        right: 0,
    },
    houseItemTitle:{
        fontSize:12,
        color:'#fff',
    },
    textContract:{
        width: 60,
        height: 22,
        backgroundColor: 'rgba(255, 255, 0, 0.6)',
        borderRadius: 6,
        margin: 8,
        marginTop: 43,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        top: 0,
        right: 0,
    },
    imageIcons:{
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        display:'flex',
    },
    imageIconsBed:{
        flexDirection: 'row',
        alignItems: 'center',
        marginHorizontal:20,
        marginBottom:4,
    },
    imageIconsNumber:{
        fontSize: 20,
        color: '#fff',
        fontWeight:'bold',
        marginRight:7,
    },
    IconBed:{
        padding:10,
        color:color.whiteColor,
    },
    houseItemPrice:{
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal:5
    },
    houseItemArea:{
        color:'#f17e23',
        fontSize:18,
        fontWeight:'bold',
        marginVertical: 6,
    },
    separateWidth: {
        borderBottomWidth: 1,
        borderBottomColor: '#86F9FF',
        height: 0,
        width: 171,
        marginBottom: 3,
    },
    houseItemName:{
        fontWeight:'bold',
        fontSize:16,
        marginLeft:5,
    },
    ItemContentAdress:{
        flexDirection: 'row',
    },
    IconLocation:{
        color:'#fc7c17',
        margin:8
    },
    AdressText:{
        paddingRight:35,
        paddingTop:8,
    }
});

export default styles;