// import React, { useState, useEffect, Component } from 'react';
// import { View, Text, TextInput, SafeAreaView, TouchableOpacity, Image, ImageBackground, ScrollView, FlatList } from 'react-native';
// import axios from 'axios';
// import styles from './style';
// import { LinearGradient } from 'expo-linear-gradient'
// //json-server --watch db.json --port 3001
// import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
// import { faArrowLeft } from '@fortawesome/free-solid-svg-icons/faArrowLeft'
// import { faHouse } from '@fortawesome/free-solid-svg-icons/faHouse'
// import { faBed } from '@fortawesome/free-solid-svg-icons/faBed'
// import { faBath } from '@fortawesome/free-solid-svg-icons/faBath'
// import { faLocationDot } from '@fortawesome/free-solid-svg-icons/faLocationDot'

// const Test = (colors, props) => {
//     constructor(props) {
//         super(props);
//         this.state = { housing: [] };
//     }
//     const [searchKeyword, setSearchKeyword] = useState('');
//     const [filteredHousing, setFilteredHousing] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [housingData, setHousingData] = useState([]);

//     useEffect(() => {
       
//         axios.get('http://localhost:3001/housing') // Thay URL bằng URL API của bạn
//             .then(response => {
//                 console.log('Data from API:', response.data); // Log dữ liệu nhận được từ API
//                 setHousingData(response.data);
//                 setLoading(false);
//             })
//             .catch(error => {
//                 console.error('Error fetching data:', error);
//                 setLoading(false);
//             });
//     }, []);



//     const handleSearch = (keyword) => {
//         const filtered = housingData.filter(
//             (item) =>
//                 item.name.toLowerCase().includes(keyword.toLowerCase()) ||
//                 item.location.toLowerCase().includes(keyword.toLowerCase())
//         );
//         setSearchKeyword(keyword);
//         setFilteredHousing(filtered);
//     };
//     const totalItems = filteredHousing.length;
//     return (
//         <View style={styles.container}>
//             <LinearGradient colors={['#f5b41a', '#ff6e46']} style={styles.header}>
//                 <View style={styles.titleHouse}>
//                     <FontAwesomeIcon style={styles.iconArrow} icon={faArrowLeft} />
//                     <Text style={styles.titleHeading}>Quản lý nhà ({totalItems})</Text>
//                 </View>
//                 <View style={styles.tabManagement}>
//                     <Text style={[styles.management, styles.active]}>Tất cả</Text>
//                     <Text style={styles.management}>Trống</Text>
//                     <Text style={styles.management}>Cọc</Text>
//                     <Text style={styles.management}>Đã thuê</Text>
//                 </View>
//             </LinearGradient>
//             <View style={styles.formGroup}>
//                 <TextInput
//                     style={styles.headerSearch}
//                     placeholder="Tìm kiếm"
//                     keyboardType="default"
//                     autoCapitalize="words"
//                     value={searchKeyword}
//                     onChangeText={handleSearch}
//                 />
//                 <FlatList>
//                     data = {this.state.housingData}
//                     renderItems = {({ item }) =>
//                         <houseItem items={item} />
//                     }
//                     keyExtractor={(item, index) => index.toString()}
//                 </FlatList>
//             </View>
//         </View>
//     );
// };

// export default Test;

// export class houseItem extends Component {
//     state = {}
//     render() {
//         return (
//             <View style={styles.houseList}>
//                 {filteredHousing.map((item, index) => (
//                     <View style={styles.houseItem}>
//                         <ImageBackground style={styles.imageStyleHouse} resizeMode='cover' source={this.props.items.img}>
//                             <View style={styles.imageIconHouse}>
//                                 <FontAwesomeIcon style={styles.IconHouse} icon={faHouse} />
//                             </View>
//                             <View style={styles.textHouse}>
//                                 <Text style={styles.houseItemTitle}>Nhà</Text>
//                             </View>
//                             <View style={styles.textContract}>
//                                 <Text style={styles.houseItemTitle}>Hợp đồng</Text>
//                             </View>
//                             <View style={styles.imageIcons}>
//                                 <View style={styles.imageIconsBed}>
//                                     <Text style={styles.imageIconsNumber}>{this.props.items.bed}</Text>
//                                     <FontAwesomeIcon style={styles.IconBed} icon={faBed} />
//                                 </View>
//                                 <View style={styles.imageIconsBed}>
//                                     <Text style={styles.imageIconsNumber}>{this.props.items.bath}</Text>
//                                     <FontAwesomeIcon style={styles.IconBed} icon={faBath} />
//                                 </View>
//                             </View>
//                         </ImageBackground>
//                         <View style={styles.houseItemContent}>
//                             <View style={styles.houseItemPrice}>
//                                 <Text style={styles.houseItemArea}>{this.props.items.price},000 đ</Text>
//                                 <Text style={styles.houseItemArea}>{this.props.items.area} m²</Text>
//                             </View>
//                             <View style={styles.separateWidth}></View>
//                             <View style={styles.houseItemContent}>
//                                 <Text style={styles.houseItemName}>{this.props.items.name}</Text>
//                                 <View style={styles.ItemContentAdress}>
//                                     <FontAwesomeIcon style={styles.IconLocation} icon={faLocationDot} />
//                                     <Text style={styles.AdressText}>{this.props.items.location}</Text>
//                                 </View>
//                             </View>
//                         </View>
//                     </View>
//                 ))}
//             </View>
//         );
//     }
// }



    // const Housing = [
    //     {
    //         id: 1,
    //         img: require('./../../assets/IMG1.jpg'),
    //         bed: 2,
    //         bath: 1,
    //         price: 20,
    //         area: '150',
    //         name: 'Chung cư cao cấp',
    //         location: '380 đường Đội Cấn, Phường Đội Cấn, Quận Ba Đình, Thành Phố Hà Nội'
    //     },
    //     {
    //         id: 2,
    //         img: require('./../../assets/IMG2.jpg'),
    //         bed: 0,
    //         bath: 0,
    //         price: 80,
    //         area: '1500',
    //         name: 'Cửa hàng',
    //         location: '380 đường Đội Cấn, Phường Đội Cấn, Quận Ba Đình, Thành Phố Hà Nội'
    //     },
    //     {
    //         id: 3,
    //         img: require('./../../assets/IMG3.jpg'),
    //         bed: 2,
    //         bath: 2,
    //         price: 20,
    //         area: '1500',
    //         name: 'Chung cư',
    //         location: '380 đường Đội Cấn, Phường Đội Cấn, Quận Ba Đình, Thành Phố Hà Nội'
    //     },
    //     {
    //         id: 4,
    //         img: require('./../../assets/IMG4.jpg'),
    //         bed: 2,
    //         bath: 1,
    //         price: 20,
    //         area: '150',
    //         name: 'Cao ốc',
    //         location: '380 đường Đội Cấn, Phường Đội Cấn, Quận Ba Đình, Thành Phố Hà Nội'
    //     },
    //     {
    //         id: 5,
    //         img: require('./../../assets/IMG5.jpg'),
    //         bed: 2,
    //         bath: 2,
    //         price: 20,
    //         area: '1500',
    //         name: 'Căn hộ cao cấp 1',
    //         location: '380 đường Đội Cấn, Phường Đội Cấn, Quận Ba Đình, Thành Phố Hà Nội'
    //     },
    // ];