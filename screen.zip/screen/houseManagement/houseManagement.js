import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ImageBackground, FlatList, ActivityIndicator } from 'react-native';

import styles from './style';
import { LinearGradient } from 'expo-linear-gradient'
import { useNavigation } from '@react-navigation/native';

import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons/faArrowLeft'
import { faHouse } from '@fortawesome/free-solid-svg-icons/faHouse'
import { faBed } from '@fortawesome/free-solid-svg-icons/faBed'
import { faBath } from '@fortawesome/free-solid-svg-icons/faBath'
import { faLocationDot } from '@fortawesome/free-solid-svg-icons/faLocationDot'

const HouseManagement = ({ navigation }, props) => {
    const [filteredHousing, setFilteredHousing] = useState([]);
    const [searchKeyword, setSearchKeyword] = useState('');
    const [isLoading, setisLoading] = useState(true);
    const [dsHousing, setdsHousing] = useState([]);

    const getListPro = async () => {
        let url_api = 'http://172.20.10.12:3000/housing';

        try {
            const response = await fetch(url_api); // load dữ liệu

            const json = await response.json(); // chuyển dữ liệu thành json

            setdsHousing(json);// đổ dữ liệu vào state

        } catch (error) {
            console.error(error);
        } finally {
            // kết thúc quá trình load dữ liệu, kể cả có lỗi cũng gọi vào lệnh này
            setisLoading(false); // trạng thái không còn load nữa
        }
    }
    React.useEffect(() => {
        const unsubscribe = navigation.addListener('focus', () => {
            // cập nhật giao diện ở đây
            getListPro();
        });

        return unsubscribe;
    }, [navigation]);

    const handleSearch = (keyword) => {
        setSearchKeyword(keyword); // lưu từ khóa tìm kiếm
    
        const filtered = dsHousing.filter(
            (item) =>
                item.name.toLowerCase().includes(keyword.toLowerCase()) ||
                item.location.toLowerCase().includes(keyword.toLowerCase())
        );
        setFilteredHousing(filtered); // lưu danh sách đã lọc dựa trên từ khóa tìm kiếm
    };
    const totalItems = filteredHousing.length;

    return (
        <View style={styles.container}>
            <LinearGradient colors={['#f5b41a', '#ff6e46']} style={styles.header}>
                <TouchableOpacity style={styles.titleHouse} onPress={() => { navigation.navigate('HomePage') }}>
                    <FontAwesomeIcon style={styles.iconArrow} icon={faArrowLeft} />
                    <Text style={styles.titleHeading}>Quản lý nhà ({totalItems})</Text>
                    {/* ({totalItems}) */}
                </TouchableOpacity>
                <View style={styles.tabManagement}>
                    <Text style={[styles.management, styles.active]}>Tất cả</Text>
                    <Text style={styles.management}>Trống</Text>
                    <Text style={styles.management}>Cọc</Text>
                    <Text style={styles.management}>Đã thuê</Text>
                </View>
            </LinearGradient>
            <View style={styles.formGroup}>
                <TextInput
                    style={styles.headerSearch}
                    placeholder="Tìm kiếm"
                    keyboardType="default"
                    autoCapitalize="words"
                value={searchKeyword}
                onChangeText={handleSearch}
                />
                {
                    (isLoading) ? (
                        <ActivityIndicator />
                    ) : (
                        <FlatList
                            data={dsHousing}
                            numColumns={2}
                            keyExtractor={(item) => item.id.toString()}
                            renderItem={({ item, index }) => (

                                <TouchableOpacity onPress={() => navigation.navigate('HouseDetail', { houseId: item.id })} style={styles.houseItem}>
                                    <ImageBackground style={styles.imageStyleHouse} resizeMode='cover' source={{uri:item.img}}>
                                        <View style={styles.imageIconHouse}>
                                            <FontAwesomeIcon style={styles.IconHouse} icon={faHouse} />
                                        </View>
                                        <View style={styles.textHouse}>
                                            <Text style={styles.houseItemTitle}>Nhà</Text>
                                        </View>
                                        <View style={styles.textContract}>
                                            <Text style={styles.houseItemTitle}>Hợp đồng</Text>
                                        </View>
                                        <View style={styles.imageIcons}>
                                            <View style={styles.imageIconsBed}>
                                                <Text style={styles.imageIconsNumber}>{item.bed}</Text>
                                                <FontAwesomeIcon style={styles.IconBed} icon={faBed} />
                                            </View>
                                            <View style={styles.imageIconsBed}>
                                                <Text style={styles.imageIconsNumber}>{item.bath}</Text>
                                                <FontAwesomeIcon style={styles.IconBed} icon={faBath} />
                                            </View>
                                        </View>
                                    </ImageBackground>
                                    <View style={styles.houseItemContent}>
                                        <View style={styles.houseItemPrice}>
                                            <Text style={styles.houseItemArea}>{item.price},000 đ</Text>
                                            <Text style={styles.houseItemArea}>{item.area} m²</Text>
                                        </View>
                                        <View style={styles.separateWidth}></View>
                                        <View style={styles.houseItemContent}>
                                            <Text style={styles.houseItemName}>{item.name}</Text>
                                            <View style={styles.ItemContentAdress}>
                                                <FontAwesomeIcon style={styles.IconLocation} icon={faLocationDot} />
                                                <Text style={styles.AdressText}>{item.location}</Text>
                                            </View>
                                        </View>
                                    </View>
                                </TouchableOpacity>
                            )}
                        />
                    )
                }
            </View>
        </View >
    );
};

export default HouseManagement;