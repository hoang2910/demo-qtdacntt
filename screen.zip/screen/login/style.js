import { StyleSheet } from 'react-native';

import color from '../../basecss/color'

const styles = StyleSheet.create({
    container : {
        flex : 1,
        backgroundColor: color.whiteColor,
        display: 'flex',
    },
    
    header : {
        flex: 2,
        borderBottomLeftRadius: 60,
    },
    iconArrow : {
        top: 30,
        left: 15,
        padding:15,
        color : color.whiteColor
    },
    headingHome : {
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
        marginTop: 2,
        color: '#1c3137',
    },
    heading:{
        marginTop: 15,
        textAlign: 'right',
        color: color.whiteColor,
        marginRight:20,
        fontSize: 19,
        fontWeight:'bold',
    },
    imageStyle :{
        width: 70,
        height:70,
        alignSelf: 'center',
        marginTop:50,
        borderRadius:10
    },
    formGroup:{
        flex: 7,
        backgroundColor: color.whiteColor,
    },
    spacer:{
        marginBottom: 60
    },
    formControl:{
        width: 370,
        minHeight: 5,
        padding: 10,
        backgroundColor: '#fff',
        borderRadius: 13,
        margin: 10,
        marginLeft:20,
        shadowColor: 'black',
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
    },
    formSubmit:{
        justifyContent:'center',
        alignItems: 'center',
        marginTop: 25,
        padding: 10,
        marginLeft: 25,
        borderRadius: 10,
        backgroundColor:'#fe7910',
        width: 360,
    },
    submitText:{
        color: color.whiteColor,
        fontSize: 20,
        fontWeight:'500'
    },
    fogetPass:{
        color:'#f17e23',
        marginLeft:280,
        fontSize:16,
        marginTop:10,
        fontWeight:'500',
    },
    account :{
        justifyContent:'center',
        alignItems: 'center',
        marginTop: 20,
        flexDirection:'row'
    },
    textAccount:{
        fontSize:16,
    },
    textRegister:{
        color:'#f17e23',
        fontWeight:'500',
        fontSize:16,
    }
});

export default styles;