import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import styles from './style';
import { LinearGradient } from 'expo-linear-gradient'
//import Register from './../register/register.';


const Login = ({ navigation }, props) => {
    const [account, setaccount] = useState("");
    const [password, setpassword] = useState("");
    const doLogin = () => {
        // kiểm tra hợp lệ dữ liệu
        if (account.length == 0) {
            alert("Chưa nhập Username"); return;
        }
        if (password.length == 0) {
            alert("Chưa nhập Password"); return; // lệnh return để thoát hàm login
        }
        // thực hiện fetch để lấy dữ liệu về
        let url_check_login = "http://172.20.10.12:3000/login?account=" + account;
        fetch(url_check_login)
            .then((res) => { return res.json(); })
            .then(async (res_login) => {
                if (res_login.length != 1) {
                    alert("Sai username hoặc lỗi trùng lặp dữ liệu");
                    return;
                } else {
                    // số lượng lấy được 1 bản ghi ==> kiểm tra password
                    let objU = res_login[0];
                    if (objU.password != password) {
                        alert("Sai password"); return;
                    } else {
                        // đúng password: lưu thông tin vào storage
                        try {
                            await AsyncStorage.setItem('loginInfo', JSON.stringify(objU));
                            // chuyển màn hình sang màn hình home
                            navigation.navigate('HomePage');
                        } catch (e) {
                            // saving error
                            console.log(e);
                        }
                    }
                }
            })
    }
    return (
        <View style={styles.container}>
            <LinearGradient colors={['#f5b41a', '#ff6e46']} style={styles.header}>
                <Image style={styles.imageStyle} resizeMode='contain' source={require('./../../assets/logoApp.png')}></Image>
                <Text style={styles.headingHome}>IZZY LEASING</Text>
                <Text style={styles.heading}>ĐĂNG NHẬP</Text>
            </LinearGradient>

            <View style={styles.formGroup}>
                <View style={styles.spacer} />

                <TextInput
                    style={styles.formControl}
                    placeholder="Email hoặc Số điện thoại"
                    keyboardType="email-address"
                    autoCompleteType="email"
                    textContentType="emailAddress"
                    onChangeText={  (txt)=>{ setaccount(txt)} }
                />

                <TextInput
                    style={styles.formControl}
                    placeholder="Nhập mật khẩu"
                    secureTextEntry={true}
                    onChangeText={  (txt)=>{ setpassword(txt)} }
                />
                <Text style={styles.fogetPass}>Quên mật khẩu?</Text>
                <TouchableOpacity style={styles.formSubmit} onPress={doLogin} >
                    <Text style={styles.submitText}>ĐĂNG NHẬP</Text>
                </TouchableOpacity>
                <View style={styles.account}>
                    <Text style={styles.textAccount}>Bạn chưa có tài khoản?</Text>
                    <TouchableOpacity onPress={() => { navigation.navigate('Register') }}>
                        <Text style={styles.textRegister}> Đăng ký</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    );
};
export default Login;