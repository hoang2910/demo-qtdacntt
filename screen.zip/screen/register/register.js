import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image } from 'react-native';

import styles from './style';
import { LinearGradient } from 'expo-linear-gradient'
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons/faArrowLeft'

const Register = ({navigation}) => {
  return (
    <View style={styles.container}>
      <LinearGradient colors={['#f5b41a', '#ff6e46']} style={styles.header}>
        <TouchableOpacity onPress={() => { navigation.navigate('Login') }}>
          <FontAwesomeIcon style={styles.iconArrow} icon={faArrowLeft} />
        </TouchableOpacity>
        <Image style={styles.imageStyle} resizeMode='contain' source={require('./../../assets/logoApp.png')}></Image>
        <Text style={styles.headingHome}>IZZY LEASING</Text>
        <Text style={styles.heading}>THÔNG TIN TÀI KHOẢN</Text>
      </LinearGradient>

      <View style={styles.formGroup}>
        <View style={styles.spacer} />
        <TextInput
          style={styles.formControl}
          placeholder="Họ Tên"
          keyboardType="default"
          autoCapitalize="words"
          autoCompleteType="name"
          textContentType="name"
        />

        <TextInput
          style={styles.formControl}
          placeholder="Email"
          keyboardType="email-address"
          autoCompleteType="email"
          textContentType="emailAddress"
        />

        <TextInput
          style={styles.formControl}
          placeholder="Số điện thoại"
        />

        <TextInput
          style={styles.formControl}
          placeholder="Nhập mật khẩu"
          secureTextEntry={true}
        />

        <TextInput
          style={styles.formControl}
          placeholder="Nhập lại mật khẩu"
          secureTextEntry={true}
        />

        <TouchableOpacity style={styles.formSubmit} >
          <Text style={styles.submitText}>TẠO TÀI KHOẢN</Text>
        </TouchableOpacity>
        <View style={styles.account}>
          <Text style={styles.textAccount}>Bạn đã có tài khoản?</Text>
          <TouchableOpacity onPress={() => { navigation.navigate('Login') }}>
            <Text style={styles.textRegister}> Đăng nhập</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default Register;