import { StyleSheet } from 'react-native';

import color from '../../basecss/color'

const styles = StyleSheet.create({
    separateWidth: {
        borderBottomWidth: 1,
        borderBottomColor: '#999',
        height: 0,
        width: '98%',
    },
    color: {
        color: '#ff6e46',
    },
    container: {
        flex: 1,
        position: 'relative',
        backgroundColor: color.whiteColor,
    },
    header: {
        flex: 2,
        borderBottomLeftRadius: 50,
        borderBottomRightRadius: 50,
    },
    titlle:{
        display : 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 35,
    },
    headerbackgroundimg: {
        padding:14,
        backgroundColor: color.whiteColor,
        borderRadius:200,
        marginLeft:10,
        marginTop:10,
    },
    iconheader:{
        padding:12,
        color: '#333',
    },
    UserName:{
        color: 'white',
        fontSize:18,
        fontWeight: 'bold',
        alignItems: 'center',
        marginLeft:20,
        marginTop:12,
    },
    formGroup: {
        flex: 8,
        backgroundColor: '#f1f1f1',
        position: 'relative',
    },
    formGroupListed:{
        marginTop: 20,
        backgroundColor: color.whiteColor,
        borderRadius: 15,
        paddingVertical: 16,
        paddingHorizontal: 20,
        marginHorizontal: 12,
        flexDirection: 'row',
        shadowColor: 'black',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
        width: '94%',
        backgroundColor: '#f1f1f1',
        flexWrap: 'wrap',
        position: 'absolute',
        top: -70,
    },
    formGroupItems:{
        display : 'flex',
        flexDirection: 'row',
        alignItems: 'center', 
        width: '100%',
        paddingVertical:15,
        justifyContent: 'space-between',
    },
    ItemLeft:{
        display: 'flex',
        flexDirection: 'row',
        alignContent: 'center',
    },
    iconArowRight:{
        right: 10,
    },
    ItemsText:{
        color: color.blackColor,
        fontSize:18,
        marginLeft:12,
    },
    formGroupNavbar: {
        flex: 1,
        backgroundColor: color.whiteColor,
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: color.whiteColor,
        paddingHorizontal:12,
        flexDirection: 'row',
    },
    iconStatic:{
        color:'#fff',
        alignItems: 'center',
        backgroundColor: '#ff6e46',
        borderRadius: 500,
        padding: 12,
    },
    navBarStatisticText:{
        marginTop: 20,
    },
    navBarcolorStatis:{
        position: 'absolute',
        alignItems: 'center',
        justifyContent  : 'center',
        top: -48,
        padding:35,
        borderRadius:500,
        backgroundColor: '#fff',
        shadowColor: 'black',
    },
    navBarStatic:{
        padding: 10,
        backgroundColor: '#ff6e46',
        position: 'absolute',
        borderRadius:200,
    },
    iconNavbar:{
        padding: 14,
        alignItems: 'center',
        justifyContent: 'center',
        color: '#333',
    },
    navBar:{
        alignItems: 'center',
        justifyContent: 'center',
    }
});

export default styles;