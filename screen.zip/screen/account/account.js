import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ImageBackground, ScrollView, Image } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import styles from './style';
import { LinearGradient } from 'expo-linear-gradient'

import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { faCircleUser } from '@fortawesome/free-solid-svg-icons/faCircleUser'
import { faPeopleRoof } from '@fortawesome/free-solid-svg-icons/faPeopleRoof'
import { faMoneyBillTransfer } from '@fortawesome/free-solid-svg-icons/faMoneyBillTransfer'
import { faBell } from '@fortawesome/free-solid-svg-icons/faBell'
import { faChartLine } from '@fortawesome/free-solid-svg-icons/faChartLine'
import { faChevronRight } from '@fortawesome/free-solid-svg-icons/faChevronRight'
import { faLock } from '@fortawesome/free-solid-svg-icons/faLock'
import { faArrowRightFromBracket } from '@fortawesome/free-solid-svg-icons/faArrowRightFromBracket'
import { faBan } from '@fortawesome/free-solid-svg-icons/faBan'



const Account = ({ navigation }) => {
    const [loginInfo, setLoginInfo] = useState({});

    const getLoginInfo = async () => {
        try {
            const value = await AsyncStorage.getItem('loginInfo');
            if (value !== null) {
                // lấy được dữ liệu
                setLoginInfo(JSON.parse(value));
            }
        } catch (e) {
            // error reading value
            console.log(e);
        }
    };

    const handleLogoutAndClearData = () => {
        navigation.dispatch(
            navigation.reset({
                index: 0, // Đặt index về 0 để chỉ định màn hình đầu tiên trong stack mới
                routes: [
                    { name: 'Login' } // Thay 'NewScreen' bằng tên màn hình mới bạn muốn chuyển đến
                ]
            })
        );
    };

    React.useEffect(() => {
        const unsubscribe = navigation.addListener('focus', () => {
            // khi màn hình được active thì lệnh trong này hoạt động
            getLoginInfo();
        });

        return unsubscribe;
    }, [navigation]);
    return (
        <View style={styles.container}>
            <LinearGradient colors={['#f5b41a', '#ff6e46']} style={styles.header}>
                <View style={styles.titlle}>
                    <View style={styles.headerbackgroundimg}>
                        <FontAwesomeIcon style={styles.iconheader} icon={faCircleUser} />
                    </View>
                    <Text style={styles.UserName}>{loginInfo.name}</Text>
                </View>
            </LinearGradient>
            <View style={styles.formGroup}>
                <View style={styles.formGroupListed}>
                    <View style={styles.formGroupItems}>
                        <View style={styles.ItemLeft}>
                            <FontAwesomeIcon style={styles.iconheader} icon={faCircleUser} />
                            <Text style={styles.ItemsText}>Thông tin cá nhân</Text>
                        </View>
                        <FontAwesomeIcon style={styles.iconArowRight} icon={faChevronRight} />
                    </View>
                    <View style={styles.separateWidth}></View>
                    <View style={styles.formGroupItems}>
                        <View style={styles.ItemLeft}>
                            <FontAwesomeIcon style={styles.iconheader} icon={faLock} />
                            <Text style={styles.ItemsText}>Đổi mật khẩu</Text>
                        </View>
                        <FontAwesomeIcon style={styles.iconArowRight} icon={faChevronRight} />
                    </View>
                    <View style={styles.separateWidth}></View>
                    <TouchableOpacity onPress={handleLogoutAndClearData}>
                        <View style={styles.formGroupItems}>
                            <View style={styles.ItemLeft}>
                                <FontAwesomeIcon style={styles.iconheader} icon={faArrowRightFromBracket} />
                                <Text style={styles.ItemsText}>Đăng xuất</Text>
                            </View>
                            <FontAwesomeIcon style={styles.iconArowRight} icon={faChevronRight} />
                        </View>
                    </TouchableOpacity>
                    <View style={styles.separateWidth}></View>
                    <View style={styles.formGroupItems}>
                        <View style={styles.ItemLeft}>
                            <FontAwesomeIcon style={styles.iconheader} icon={faBan} />
                            <Text style={styles.ItemsText}>Xóa tài Khoản</Text>
                        </View>
                    </View>
                </View>
            </View>
            <View style={styles.formGroupNavbar}>
                <TouchableOpacity style={styles.formSubmit} onPress={() => { navigation.navigate('HomePage') }}>
                    <View style={styles.navBar}>
                        <FontAwesomeIcon style={[styles.iconNavbar]} icon={faPeopleRoof} />
                        <Text style={styles.navBarHomePageText}>Trang chủ</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.navBar}>
                    <FontAwesomeIcon style={styles.iconNavbar} icon={faMoneyBillTransfer} />
                    <Text style={styles.navBarBillText}>Hợp đồng</Text>
                </View>
                <TouchableOpacity style={styles.formSubmit} onPress={() => { navigation.navigate('Dashboard') }}>
                    <View style={styles.navBar}>
                        <View style={styles.navBarcolorStatis}>
                            <View style={styles.navBarStatic}>
                                <FontAwesomeIcon style={[styles.iconStatic]} icon={faChartLine} />
                            </View>
                        </View>
                        <Text style={styles.navBarStatisticText}>Thống kê</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.navBar}>
                    <FontAwesomeIcon style={styles.iconNavbar} icon={faBell} />
                    <Text style={styles.navBarAlertText}>Thông Báo</Text>
                </View>
                <TouchableOpacity style={styles.formSubmit} onPress={() => { navigation.navigate('Account') }}>
                    <View style={styles.navBar}>
                        <FontAwesomeIcon style={[styles.iconNavbar, styles.color]} icon={faCircleUser} />
                        <Text style={styles.navBarUserText}>Tài Khoản</Text>
                    </View>
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default Account;