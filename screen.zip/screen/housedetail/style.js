import { StyleSheet } from 'react-native';

import color from '../../basecss/color'

const styles = StyleSheet.create({
    separateWidth: {
        borderBottomWidth: 1,
        borderBottomColor: '#ADD8E6',
        height: 0,
        width: '100%',
        marginBottom: 3,
    },
    container: {
        flex: 1,
        backgroundColor:'#f3f3f3',
    },
    
    ImageBackgroundHeader:{
        flex: 3,
        backgroundColor:'#999',
    },
    headerImage:{
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop:40,
        marginHorizontal:12,
    },
    iconArrow:{
        padding:12,
        color : color.whiteColor
    },
    titleheaderImageLeft:{
        color: color.whiteColor,
        fontSize:18,
        marginLeft:10,
    },
    headerImageLeft:{
        display: 'flex',
        flexDirection: 'row',
    },
    headerImageRight:{
        display: 'flex',
        flexDirection: 'row',
    },
    iconheaderImageRight:{
        padding:12,
        color: color.whiteColor,
        marginLeft:18,
    },
    imageStyleHouse:{
        width:'100%',
        height:'100%',
    },
    imgiconnextandrev:{
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop:70,
        marginHorizontal:12,
    },
    iconLeftAndRight:{
        color:'#ff6e46',
        padding:10,
        backgroundColor:color.whiteColor,
        borderRadius:100,
    },
    imgiconLeftAndRightBoder:{
        padding:7,
        backgroundColor:color.whiteColor,
        borderRadius:100,
    },
    imgiconbathandbedRoom:{
        display: 'flex',
        flexDirection: 'row',
        marginHorizontal:12,
        marginTop:70,
        alignItems: 'center',
    },
    IconBedandbath:{
        padding:11,
        marginRight:5,
        color:color.whiteColor,
    },
    textbathandbedRoom:{
        fontSize:16,
        color:color.whiteColor,
        paddingRight:18,

    },
    bodydetailhouse:{
        flex: 7,
    },
    bodydetailHeader:{
        backgroundColor:color.whiteColor,
        shadowColor: 'black',
        shadowOffset: {
            width: 0,
            height: 10,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
        borderRadius:10,
        padding:14,
    },
    priceandArea:{
        display:'flex',
        flexDirection:'row',
        justifyContent:'space-between'
    },
    headerprice:{
        fontSize:20,
        color:'#ff6e46',
        fontWeight:'bold',
        marginBottom:12,
    },
    headerlocation:{
        display:'flex',
        flexDirection:'row',
        alignItems:'center',
        marginTop:12,
    },
    IconLocation:{
        color:'#ff6e46',
        marginRight:10,
    },
    headerlocationtext:{
        fontSize: 16,
        paddingRight:18,
        color:color.blackColor,
    },
    bodydescribe:{
        backgroundColor:color.whiteColor,
        shadowColor: 'black',
        shadowOffset: {
            width: 0,
            height: 10,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
        borderRadius:15,
        padding:14,
        margin:10,
        marginTop:20,
        marginBottom:30,
    },
    bodydescribeContract:{
        display:'flex',
        flexDirection:'row',
        alignItems:'center',
        marginBottom:8,
    },
    IconContractandkey:{
        padding: 10,
        marginRight:10,
        color:'#f1c429',
    },
    ContractandkeyText:{
        color:'#f1c429',
        fontSize:18,
        fontWeight:'bold',
    },
    bodydescribeTitle:{
        display:'flex',
        flexDirection:'row',
        justifyContent: 'space-between',
    },
    describeTitletext:{
        fontSize:20,
        fontWeight:'bold',
        marginBottom:6,
    },
    bodydescribeDetail:{
        fontSize:15,
        color:color.blackColor,
    },
    bodymanage:{
        width: '100%',
        display: 'flex',
        flexDirection:'row',
        alignItems:'center',
        flexWrap: 'wrap',
    },
    manage:{
        width:'25%',
        display: 'flex',
        justifyContent: 'center',
        alignItems  : 'center',
    },
    manageIcon:{
        padding:12,
        color:'#ff6e46',
        backgroundColor:color.whiteColor,
        borderRadius:50,
    },
    backgroundmanage:{
        padding:16,
        backgroundColor:color.whiteColor,
        borderRadius:50,
        shadowColor: 'black',
        shadowOffset: {
            width: 0,
            height: 10,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
    },
    manageText:{
        fontSize:16,
        color:color.blackColor,
        marginVertical:8,
        marginBottom:20,
    },
});

export default styles;