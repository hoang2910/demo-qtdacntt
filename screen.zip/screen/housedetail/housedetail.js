import React, { useState, useEffect  } from 'react';
import { View, Text, TextInput, TouchableOpacity, ImageBackground, ScrollView, Image } from 'react-native';

import styles from './style';
import { LinearGradient } from 'expo-linear-gradient'
import { useRoute } from '@react-navigation/native';

import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons/faArrowLeft'
import { faPencil } from '@fortawesome/free-solid-svg-icons/faPencil'
import { faTrashCan } from '@fortawesome/free-solid-svg-icons/faTrashCan'
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons/faChevronLeft'
import { faChevronRight } from '@fortawesome/free-solid-svg-icons/faChevronRight'
import { faBed } from '@fortawesome/free-solid-svg-icons/faBed'
import { faBath } from '@fortawesome/free-solid-svg-icons/faBath'
import { faLocationDot } from '@fortawesome/free-solid-svg-icons/faLocationDot'
import { faFileContract } from '@fortawesome/free-solid-svg-icons/faFileContract'
import { faKey } from '@fortawesome/free-solid-svg-icons/faKey'
import { faUserTie } from '@fortawesome/free-solid-svg-icons/faUserTie'
import { faCoins } from '@fortawesome/free-solid-svg-icons/faCoins'
import { faHouseLaptop } from '@fortawesome/free-solid-svg-icons/faHouseLaptop'

const HouseDetail = ({ navigation }) => {
    const route = useRoute();
    const { houseId } = route.params;

    const [isLoading, setIsLoading] = useState(true);
    const [houseInfo, setHouseInfo] = useState(null);

    const fetchHouseDetails = async () => {
        try {
            const response = await fetch(`http://172.20.10.12:3000/housing/${houseId}`);
            const data = await response.json();
            setHouseInfo(data);
        } catch (error) {
            console.error(error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchHouseDetails();
    }, []); // Gọi fetchHouseDetails khi component được tạo

    
    return (
        <View style={styles.container}>
            <View style={styles.ImageBackgroundHeader}>
                <ImageBackground style={styles.imageStyleHouse} resizeMode='cover' source={require('./../../assets/IMG4.jpg')}>
                    <View style={styles.headerImage}>
                        <TouchableOpacity onPress={() => { navigation.navigate('HouseManagement') }} style={styles.headerImageLeft}>
                            <FontAwesomeIcon style={styles.iconArrow} icon={faArrowLeft} />
                            <Text style={styles.titleheaderImageLeft}>Chung cư cao cấp</Text>
                        </TouchableOpacity>
                        <View style={styles.headerImageRight}>
                            <FontAwesomeIcon style={styles.iconheaderImageRight} icon={faPencil} />
                            <FontAwesomeIcon style={styles.iconheaderImageRight} icon={faTrashCan} />
                        </View>
                    </View>
                    <View style={styles.imgiconnextandrev}>
                        <View style={styles.imgiconLeftAndRightBoder}>
                            <FontAwesomeIcon style={styles.iconLeftAndRight} icon={faChevronLeft} />
                        </View>
                        <View style={styles.imgiconLeftAndRightBoder}>
                            <FontAwesomeIcon style={styles.iconLeftAndRight} icon={faChevronRight} />
                        </View>
                    </View>
                    <View style={styles.imgiconbathandbedRoom}>
                        <FontAwesomeIcon style={styles.IconBedandbath} icon={faBed} />
                        <Text style={styles.textbathandbedRoom}>2 Phòng ngủ</Text>
                        <FontAwesomeIcon style={styles.IconBedandbath} icon={faBath} />
                        <Text style={styles.textbathandbedRoom}>1 Phòng tắm</Text>
                    </View>
                </ImageBackground>
            </View>
            <View style={styles.bodydetailhouse}>
                <View style={styles.bodydetailHeader}>
                    <View style={styles.priceandArea}>
                        <Text style={styles.headerprice}>20,000 đ</Text>
                        <Text style={styles.headerprice}>150 m²</Text>
                    </View>
                    <View style={styles.separateWidth}></View>
                    <View style={styles.headerlocation}>
                        <FontAwesomeIcon style={styles.IconLocation} icon={faLocationDot} />
                        <Text style={styles.headerlocationtext}>Số 123, phố Dịch Vọng, Phường Dịch Vọng Hậu, Quận Cầu giấy, Thành phố Hà Nội</Text>
                    </View>
                </View>
                <View style={styles.bodydescribe}>
                    <View style={styles.bodydescribeContract}>
                        <FontAwesomeIcon style={styles.IconContractandkey} icon={faFileContract} />
                        <Text style={styles.ContractandkeyText}>Hợp đồng</Text>
                    </View>
                    <View style={styles.bodydescribeContract}>
                        <FontAwesomeIcon style={styles.IconContractandkey} icon={faKey} />
                        <Text style={styles.ContractandkeyText}>Đang đặt cọc</Text>
                    </View>
                    <View style={styles.bodydescribeTitle}>
                        <Text style={styles.describeTitletext}>Mô tả</Text>
                        <Text style={styles.describeTitletext}>Cao Ốc</Text>
                    </View>
                    <Text style={styles.bodydescribeDetail}>
                        Cao ốc hiện đại nằm ở trung tâm thành phố, với thiết kế độc đáo và sang trọng, tạo nên bức tranh ấn tượng kết hợp với tiện ích đẳng cấp
                    </Text>
                </View>
                <View style={styles.bodymanage}>
                    <View style={styles.manage}>
                        <View style={styles.backgroundmanage}>
                            <FontAwesomeIcon style={styles.manageIcon} icon={faUserTie} />
                        </View>
                        <Text style={styles.manageText}>Khách thuê</Text>
                    </View>
                    <View style={styles.manage}>
                        <View style={styles.backgroundmanage}>
                            <FontAwesomeIcon style={styles.manageIcon} icon={faFileContract} />
                        </View>
                        <Text style={styles.manageText}>Hợp đồng</Text>
                    </View>
                    <View style={styles.manage}>
                        <View style={styles.backgroundmanage}>
                            <FontAwesomeIcon style={styles.manageIcon} icon={faCoins} />
                        </View>
                        <Text style={styles.manageText}>Hóa đơn</Text>
                    </View>
                    <View style={styles.manage}>
                        <View style={styles.backgroundmanage}>
                            <FontAwesomeIcon style={styles.manageIcon} icon={faHouseLaptop} />
                        </View>
                        <Text style={styles.manageText}>Tài sản</Text>
                    </View>
                    <View style={styles.manage}>
                        <View style={styles.backgroundmanage}>
                            <FontAwesomeIcon style={styles.manageIcon} icon={faKey} />
                        </View>
                        <Text style={styles.manageText}>Cọc giữ chỗ</Text>
                    </View>
                </View>
            </View>
        </View>
    );
};

export default HouseDetail;