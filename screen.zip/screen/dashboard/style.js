import { StyleSheet } from 'react-native';

import color from '../../basecss/color'

const styles = StyleSheet.create({
    separateWidth: {
        borderBottomWidth: 1,
        borderBottomColor: '#ADD8E6',
        height: 0,
        width: '80%',
    },
    color: {
        color: '#ff6e46',
    },
    container: {
        flex: 1,
        position: 'relative',
        backgroundColor: color.whiteColor,
    },
    header: {
        flex: 4,
        borderBottomLeftRadius: 50,
        borderBottomRightRadius: 50,
    },
    titlle:{
        display : 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 35,
        justifyContent: 'center',
    },
    titlleText:{
        color: color.whiteColor,
        fontSize: 18,
        marginTop: 18,
    },
    bodydashboard:{
        flex: 32,
        backgroundColor: '#f1f1f1',
        position: 'relative',
        marginTop:10,
    },
    bodydashboardOverView:{
        backgroundColor: color.whiteColor,
        borderRadius:18,
        shadowColor: 'black',
        shadowOffset: {
            width: 0,
            height: 10,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
    },
    BodyheaderText:{
        fontSize: 18,
        fontWeight: 'bold',
        padding:14,
    },
    bodyTotal:{
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    TotalRevenue:{
        borderWidth: 1,
        borderRadius:5,
        borderColor: color.blackColor,
        marginHorizontal:14,
        padding:14,
        display:'flex',
        alignItems: 'center',
    },
    TotalText:{
        color: color.blackColor,
        fontSize: 16,
        fontWeight: '500',
    },
    TotalRevenueNumber:{
        color: color.blackColor,
        fontSize: 22,
        fontWeight: '500',
    },
    StatisticsByPercentage:{
        width:'100%',
        display: 'flex',
        flexDirection: 'row',        
        margin:4,
    },
    StatisticsByPercenhired:{
        width:'28%',
        paddingVertical:14,
        margin:10,
        shadowColor: '#999',
        shadowOffset: {
            width: 10,
            height: 10,
        },
        shadowOpacity: 0.2,
        shadowRadius: 3.84,
        elevation: 2,
        borderRadius:8,
        display: 'flex',
        justifyContent: 'center',
        alignItems  : 'center',
    },
    StatisticsByPercenText:{
        width:'28%',
        padding:8,
        margin:10,
        borderRadius:5,
    },
    RentHouseText:{
        fontSize:18,
        color: color.blackColor,
    },
    RentHousePercent:{
        width:70,
        height:70,
        borderRadius:500,
        borderWidth:7,
        borderColor:'#666',
        margin:8,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    RentHousePercentText:{
        padding:8,
    },
    RentHouseNumber:{
        display: 'flex',
        flexDirection :'row', 
    },
    RentHouseNumberhired:{
        borderBottomWidth: 5,
        borderBottomColor: '#ff6e46',
        height: 'auto',
        width: '38%',
        marginHorizontal:2,
        fontSize:18,
        fontWeight: 'bold',
    },
    RentHouseNumberEmpty:{
        borderBottomWidth: 5,
        borderBottomColor: '#666',
        height: 'auto',
        width: '38%',
        marginHorizontal:2,
        fontSize:18,
        fontWeight: 'bold',
    },
    RentHouselease:{
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom:4,
    },
    RentHouseleaseboderleft:{
        width: 22,
        height: 6,
        borderRadius: 5,
        backgroundColor:'#ff6e46',
        marginRight:12,
    },
    RentHouseEmptyboderleft:{
        width: 22,
        height: 6,
        borderRadius: 5,
        backgroundColor:'#666',
        marginRight:12,
    },
    RentHouseleaseText:{
        color: color.blackColor,
        fontSize: 16,
    },
    CollectMoney:{
        marginTop: 20,
        backgroundColor: color.whiteColor,
        borderRadius:18,
        shadowColor: 'black',
        shadowOffset: {
            width: 0,
            height: 10,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
    },
    CollectMoneyAndNot:{
        marginLeft:260
    },
    ListChartByMonney:{
        display: 'flex',
        flexDirection: 'row',
        width: '90%',
        paddingHorizontal:14,
    },
    ColMoney:{
        width: '12%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    ColMoneyText:{
        marginVertical:5,
        fontSize: 16,
        color:'#999'
    },
    ColDashText:{
        marginVertical:5,
        fontSize: 16,
        color:'#999',
        marginLeft: 10
    },
    ListChartByMonths:{
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    ItemsChartbyMonths:{
        paddingHorizontal: 8,
        fontSize: 14,
        color:'#777',
        marginVertical: 3,
        marginBottom: 20,
    },
    formGroupNavbar: {
        flex: 3,
        backgroundColor: color.whiteColor,
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: color.whiteColor,
        paddingHorizontal:12,
        flexDirection: 'row',
    },
    iconStatic:{
        color:'#fff',
        alignItems: 'center',
        backgroundColor: '#ff6e46',
        borderRadius: 500,
        padding: 12,
    },
    navBarStatisticText:{
        marginTop: 20,
    },
    navBarcolorStatis:{
        position: 'absolute',
        alignItems: 'center',
        justifyContent  : 'center',
        top: -40,
        padding:35,
        borderRadius:500,
        backgroundColor: '#fff',
        shadowColor: 'black',
    },
    navBarStatic:{
        padding: 10,
        backgroundColor: '#ff6e46',
        position: 'absolute',
        borderRadius:200,
    },
    iconNavbar:{
        padding: 14,
        alignItems: 'center',
        justifyContent: 'center',
        color: '#333',
    },
    navBar:{
        alignItems: 'center',
        justifyContent: 'center',
    }

});

export default styles;