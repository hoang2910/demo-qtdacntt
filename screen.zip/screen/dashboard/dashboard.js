import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ImageBackground, ScrollView, Image } from 'react-native';

import styles from './style';
import { LinearGradient } from 'expo-linear-gradient'

import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { faCircleUser } from '@fortawesome/free-solid-svg-icons/faCircleUser'
import { faPeopleRoof } from '@fortawesome/free-solid-svg-icons/faPeopleRoof'
import { faMoneyBillTransfer } from '@fortawesome/free-solid-svg-icons/faMoneyBillTransfer'
import { faBell } from '@fortawesome/free-solid-svg-icons/faBell'
import { faChartLine } from '@fortawesome/free-solid-svg-icons/faChartLine'

const Dashboard = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <LinearGradient colors={['#f5b41a', '#ff6e46']} style={styles.header}>
                <View style={styles.titlle}>
                    <Text style={styles.titlleText}>Dashboard</Text>
                </View>
            </LinearGradient>
            <View style={styles.bodydashboard}>
                <View style={styles.bodydashboardOverView}>
                    <Text style={styles.BodyheaderText}>Tổng quan</Text>
                    <View style={styles.bodyTotal}>
                        <View style={styles.TotalRevenue}>
                            <Text style={styles.TotalText}>Tổng Doanh thu</Text>
                            <Text style={styles.TotalRevenueNumber}>0 đ</Text>
                        </View>
                        <View style={styles.TotalRevenue}>
                            <Text style={styles.TotalText}>Tổng Khách thuê</Text>
                            <Text style={styles.TotalRevenueNumber}>5</Text>
                        </View>
                    </View>
                    <View style={styles.StatisticsByPercentage}>
                        <View style={styles.StatisticsByPercenhired}>
                            <Text style={styles.RentHouseText}>Thuê Nhà</Text>
                            <View style={styles.RentHousePercent}>
                                <Text style={styles.RentHousePercentText}>12%</Text>
                            </View>
                            <View style={styles.separateWidth}></View>
                            <View style={styles.RentHouseNumber}>
                                <Text style={styles.RentHouseNumberhired}>0</Text>
                                <Text style={styles.RentHouseNumberEmpty}>5</Text>
                            </View>
                        </View>
                        <View style={styles.StatisticsByPercenhired}>
                            <Text style={styles.RentHouseText}>Thuê Phòng</Text>
                            <View style={styles.RentHousePercent}>
                                <Text style={styles.RentHousePercentText}>16%</Text>
                            </View>
                            <View style={styles.separateWidth}></View>
                            <View style={styles.RentHouseNumber}>
                                <Text style={styles.RentHouseNumberhired}>0</Text>
                                <Text style={styles.RentHouseNumberEmpty}>7</Text>
                            </View>
                        </View>
                        <View style={styles.StatisticsByPercenText}>
                            <View style={styles.RentHouselease}>
                                <View style={styles.RentHouseleaseboderleft}></View>
                                <Text style={styles.RentHouseleaseText}>Cho thuê</Text>
                            </View>

                            <View style={styles.RentHouselease}>
                                <View style={styles.RentHouseEmptyboderleft}></View>
                                <Text style={styles.RentHouseleaseText}>Còn trống</Text>
                            </View>
                        </View>
                    </View>
                </View>
                <View style={styles.CollectMoney}>
                    <Text style={styles.BodyheaderText}>Thu tiền thuê</Text>
                    <View style={styles.CollectMoneyAndNot}>
                        <View style={styles.RentHouselease}>
                            <View style={styles.RentHouseleaseboderleft}></View>
                            <Text style={styles.RentHouseleaseText}>Đã thu tiền</Text>
                        </View>
                        <View style={styles.RentHouselease}>
                            <View style={styles.RentHouseEmptyboderleft}></View>
                            <Text style={styles.RentHouseleaseText}>Chưa thu tiền</Text>
                        </View>
                    </View>
                    <View style={styles.CollectMoneyChart}>
                        <View style={styles.ListChartByMonney}>
                            <View style={styles.ColMoney}>
                                <Text style={styles.ColMoneyText}>60M</Text>
                                <Text style={styles.ColMoneyText}>50M</Text>
                                <Text style={styles.ColMoneyText}>40M</Text>
                                <Text style={styles.ColMoneyText}>30M</Text>
                                <Text style={styles.ColMoneyText}>20M</Text>
                                <Text style={styles.ColMoneyText}>10M</Text>
                                <Text style={styles.ColMoneyText}>0</Text>
                            </View>
                            <View style={styles.ColDash}>
                                <Text style={styles.ColDashText}>-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -</Text>
                                <Text style={styles.ColDashText}>-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -</Text>
                                <Text style={styles.ColDashText}>-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -</Text>
                                <Text style={styles.ColDashText}>-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -</Text>
                                <Text style={styles.ColDashText}>-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -</Text>
                                <Text style={styles.ColDashText}>-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -</Text>
                                <Text style={styles.ColDashText}>-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -</Text>
                            </View>
                        </View>
                        <View style={styles.ListChartByMonths}>
                            <Text style={styles.ItemsChartbyMonths}>Aug23</Text>
                            <Text style={styles.ItemsChartbyMonths}>Sep23</Text>
                            <Text style={styles.ItemsChartbyMonths}>Oct23</Text>
                            <Text style={styles.ItemsChartbyMonths}>Nov23</Text>
                            <Text style={styles.ItemsChartbyMonths}>Dec23</Text>
                        </View>
                    </View>
                </View>
            </View>
            <View style={styles.formGroupNavbar}>
                <TouchableOpacity style={styles.formSubmit} onPress={() => { navigation.navigate('HomePage') }}>
                    <View style={styles.navBar}>
                        <FontAwesomeIcon style={[styles.iconNavbar]} icon={faPeopleRoof} />
                        <Text style={styles.navBarHomePageText}>Trang chủ</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.navBar}>
                    <FontAwesomeIcon style={styles.iconNavbar} icon={faMoneyBillTransfer} />
                    <Text style={styles.navBarBillText}>Hợp đồng</Text>
                </View>
                <TouchableOpacity style={styles.formSubmit} onPress={() => { navigation.navigate('Dashboard') }}>
                    <View style={styles.navBar}>
                        <View style={styles.navBarcolorStatis}>
                            <View style={styles.navBarStatic}>
                                <FontAwesomeIcon style={[styles.iconStatic]} icon={faChartLine} />
                            </View>
                        </View>
                        <Text style={styles.navBarStatisticText}>Thống kê</Text>
                    </View>
                </TouchableOpacity>
                <View style={styles.navBar}>
                    <FontAwesomeIcon style={styles.iconNavbar} icon={faBell} />
                    <Text style={styles.navBarAlertText}>Thông Báo</Text>
                </View>
                <TouchableOpacity style={styles.formSubmit} onPress={() => { navigation.navigate('Account') }}>
                    <View style={styles.navBar}>
                        <FontAwesomeIcon style={[styles.iconNavbar]} icon={faCircleUser} />
                        <Text style={styles.navBarUserText}>Tài Khoản</Text>
                    </View>
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default Dashboard;