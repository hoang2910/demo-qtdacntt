import { StyleSheet } from 'react-native';

import color from '../../basecss/color'

const styles = StyleSheet.create({
    separateWidth: {
        borderBottomWidth: 1,
        borderBottomColor: '#ADD8E6',
        height: 0,
        width: '100%',
        marginBottom: 3,
    },
    container:{
        flex: 1,
        backgroundColor:'#f3f3f3',
    },
    headerTenants:{
        flex: 2,
        borderBottomLeftRadius: 50,
        borderBottomRightRadius: 50,
    },
    titleTenants:{
        padding:14,
        display: 'flex',
        flexDirection: 'row',
        marginTop:30,
        alignContent: 'center',
    },
    iconArrow:{
        padding:14,
        color: color.whiteColor,
    },
    titleHeading:{
        fontSize:18,
        color: color.whiteColor,
        marginLeft:10,
    },
    bodyTenants:{
        flex: 10,
        height: 'auto'
    },
    headerSearch:{
        width: 385,
        height: 50,
        padding: 7,
        backgroundColor: '#fff',
        borderRadius: 13,
        marginTop: -45,
        marginLeft:14,
        shadowColor: 'black',
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
        marginBottom:20,
    },
    tenantInformation:{
        padding: 12,
        margin:14,
        backgroundColor:color.whiteColor,
        borderRadius: 13,
        shadowColor: 'black',
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 1,
        shadowRadius: 3.84,
        elevation: 10,
        marginBottom:10,
    },
    tenantname:{
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom:10,
    },
    nametenant:{
        fontSize:20,
        fontWeight: 'bold',
        color: color.blackColor,
    },
    iconFunction:{
        color:'#ff6e46',
        padding:10,
    },
    tenantPhoneNumber:{
        fontSize:16,
        marginTop:10,
    }

});

export default styles;