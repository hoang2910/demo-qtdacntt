import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ImageBackground, ScrollView, Image } from 'react-native';

import styles from './style';
import { LinearGradient } from 'expo-linear-gradient'

import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons/faArrowLeft'
import { faEllipsisVertical } from '@fortawesome/free-solid-svg-icons/faEllipsisVertical'


const Tenants = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <LinearGradient colors={['#f5b41a', '#ff6e46']} style={styles.headerTenants}>
                <TouchableOpacity style={styles.titleTenants} onPress={() => { navigation.navigate('HomePage') }}>
                    <FontAwesomeIcon style={styles.iconArrow} icon={faArrowLeft} />
                    <Text style={styles.titleHeading}>Khách thuê</Text>
                </TouchableOpacity>
            </LinearGradient>
            <View style={styles.bodyTenants}>
                <TextInput
                    style={styles.headerSearch}
                    placeholder="Tìm kiếm"
                    keyboardType="default"
                    autoCapitalize="words"
                    // value={searchKeyword}
                    // onChangeText={handleSearch}
                />
                <ScrollView>
                    <View style={styles.tenantInformation}>
                        <View style={styles.tenantname}>
                            <Text style={styles.nametenant}>Phạm Văn Hoàng</Text>
                            <FontAwesomeIcon style={styles.iconFunction} icon={faEllipsisVertical} />
                        </View>
                        <View style={styles.separateWidth}></View>
                        <Text style={styles.tenantPhoneNumber}>Số điện thoại: 0123456789</Text>
                    </View>
                    <View style={styles.tenantInformation}>
                        <View style={styles.tenantname}>
                            <Text style={styles.nametenant}>Bùi Hải Anh</Text>
                            <FontAwesomeIcon style={styles.iconFunction} icon={faEllipsisVertical} />
                        </View>
                        <View style={styles.separateWidth}></View>
                        <Text style={styles.tenantPhoneNumber}>Số điện thoại: 0123456789</Text>
                    </View>
                </ScrollView>
            </View>
        </View>
    );
};

export default Tenants;